﻿namespace Presentation
{
    public static class AssemblyReference
    {
    }
}
